#!/bin/bash

cd ~/Lucky_Duck_Investigation/Roulette_Loss_Investigation/Dealer_Analysis

# $1 finds the roulette dealer at a specific date form mmdy
# $2 finds the roulette dealer at a specific time form "00:00:00 AM|PM"

cat $1_Dealer_schedule | grep "$2" | awk -F" " '{print $1,$2,$5,$6}'


