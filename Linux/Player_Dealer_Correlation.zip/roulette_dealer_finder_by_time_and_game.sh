#!/bin/bash

cd ~/Lucky_Duck_Investigation/Roulette_Loss_Investigation/Dealer_Analysis

# $1 finds the dealers at a specific date form mmdy
# $2 finds the dealers at a specific time form "00:00:00 AM|PM"

cat $1_Dealer_schedule | grep -E "$2"


